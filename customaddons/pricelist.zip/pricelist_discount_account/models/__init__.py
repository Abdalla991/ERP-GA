from . import yds_pricelist
from . import yds_account_invoice
from . import yds_sale_order
from . import yds_pricelist_invoice
from . import yds_mrp_bom

from . import ks_sale_order
from . import ks_account_account
from . import ks_purchase_order
from . import yds_res_partner